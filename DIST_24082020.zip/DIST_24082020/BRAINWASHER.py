# Programa [ BrainWasher ] { 08082020 } : Programa de Interface de Comandos para auxiliar na memorizacao de informacoes. 

# IMPORTS
try:
    import os, ast, colorama, psutil, platform, shutil, sys
    import tkinter as tk
    import subprocess as sbp
    import keyboard as kbd
    import win32gui as w32
    import threading as thr
    import pyperclip as ppc
    from datetime import date
    from random import randint
    #from colors import red, green, blue, color, yellow, white, cyan
    from time import time, sleep
except:
    print('Dependencies: keyboard, win32gui, pyperclip, colorama, psutil')
    print('Use [ pip install MODULENAME ] in terminal to install required dependencies')
    os.system('pause')
    sys.exit()

if platform.system()!='Windows':
    print('Sorry, work only on windows systems.')
    os.system('pause')
    sys.exit()

# Titulo
WDTITLE = 'BrainWasherCLInterface'
os.system('title '+WDTITLE)

# os.system("mode con lines=50");

colorama.init()
CY = colorama.Style.BRIGHT + colorama.Fore.CYAN
RD = colorama.Style.BRIGHT + colorama.Fore.RED
BL = colorama.Style.BRIGHT + colorama.Fore.BLUE
GR = colorama.Style.BRIGHT + colorama.Fore.GREEN
YL = colorama.Style.BRIGHT + colorama.Fore.YELLOW
WT = colorama.Style.BRIGHT + colorama.Fore.WHITE



# GLOBAL FUNCTIONS
def find_url(string):
    SET = [ 'https://','www','.com','http','://']
    for k in SET:
        if k in string: break
    return cover_substring(string,k)

def right_cover_substring(string, token):
    if not token in string: return None
    if len(token)==len(string): return token
    id1 = string.find(token)
    idx = id1
    while idx < len(string):
        if string[idx] == ' ': break
        idx = idx+1
    return string[id1:idx]

def left_cover_substring(string, token):
    if not token in string: return None
    if len(token)==len(string): return token
    id1 = string.find(token)
    if id1 == 0 : return ''
    idx = id1
    while idx >= 0:
        if string[idx] == ' ': break
        idx = idx-1
    if idx==-1: return string[0:id1]
    if string[idx]!=' ' and idx==0: return string[0:id1]
    return string[idx+1:id1]

def cover_substring(string,token):
    try:
        return left_cover_substring(string,token)+right_cover_substring(string,token)
    except:
        return ''

def print_long_pointed_list(container = [0,1,2], description = 'item :', position = 0, list_size = 10):
    count = 0
    for i in container:
        if count > position+ list_size or count < position -list_size:
            if count == position + list_size + 1 or count == position - list_size - 1:
                print('...')
        elif count == position:
            print( CY, description, i)
        else:
            print( WT, description, i)
        count = count + 1
        
def is_dirXfile(x):
    if isdir(x):
        return CY + '[-]'
    else:
        return GR + ' * '
        
def is_python_in_focus():
    return w32.GetWindowText( w32.GetForegroundWindow() )==WDTITLE
#print( is_python_in_focus() )
#os.system('pause')

def open_in_text_editor(filepath):
    try:
        os.system('start notepad++'+' "'+ filepath +'"' )
    except:
        os.system('start notepad'+' "'+ filepath +'"' )

def open_in_pdf_viewer(filepath):
    try:
        os.system('C:\\STDU\\STDUViewerApp.exe '+' "'+ filepath +'"' )
    except:
        pass

def get_partition_list():
    L = []
    for i in psutil.disk_partitions():
        L.append( os.path.join( i[0] ) )
    return list(L)

def half_sublists(LIST):
    len_LIST = len(LIST) ; half_len_LIST = int( len_LIST/2 )
    k = 0 ; q = 0
    L1 = [ LIST[k] for k in range(half_len_LIST) ]
    L2 = [ LIST[k] for k in range(half_len_LIST,len_LIST) ]
    return list(L1), list(L2)

def comments_filter(string,SET = set(['#'])):
    """ NOT_TESTED : 06082020
    
    string, set --> bool 
    
    comentary_filter : return True if a string isnt a python like commentary or similar or is a empty string, else return false.
    
    > comentary_filter * purpose ? : ignore strings beginning with # to get information from file
    """
    string = string.lstrip()
    string = string.rstrip()
    if len(string)==0: return False # Filtra linhas vazias ou em branco
    return not string[0] in SET

def try_pass(F,ARGS,message_bool=False, message='erro'):
    """ try pass function :
    F : Function possibly raising error
    ARGS : Tuple of Arguments of FINALIZADO
    message : Display warning message if catch a error
    """
    try:
        return F(*ARGS)
    except:
        if message_bool: 
            input( message )
            return None
            
def None_D(X):
    if X==None:
        return {}
    else : 
        return X
        
def None_S(X):
    if X==None:
        return ''
    else:
        return X

def progress_bar(number, max_number=10):
    len_L = len(LINE_str) - 4
    FULL = int( number*len_L/max_number )
    EMPTY = len_L - FULL
    STRING = '\n[ '+FULL*'#'+EMPTY*'-'+' ]'
    return STRING
    
def status(number, max_number=10, desc='', color_func=RD):
    len_L = len(LINE_str) - 4
    FULL = int( number*len_L/max_number )
    EMPTY = len_L - FULL
    STRING = color_func+' '+desc+' :\n'+'[ '+FULL*'#'+color_func+EMPTY*'-'+color_func+' ]'
    return STRING + WT+'\n'#+white('\n')
    
def count_ast(string):
    ast = 0
    L = len(string)
    count = 0
    while ast<L:
        if string[ast]=='*':
            ast = ast + 1
        count = count + 1
        if ast!=count: break
    return ast

def print_dict(obj):
    print()
    for key in obj.keys():
        print( 3*' ',key, ':', try_substr( str( obj[key] ),0,30) )
    print()

def try_substr(string,a,b):
    try   : 
        if   b=='all': return string[a:]
        elif a=='all': return string[:b]
        else         : return string[a:b]
    except: return None

def get_list_from_file(filepath):
    """ 
    NOT_TESTED : 06082020
    get_list_from_file : get a list of lines from a file ignoring comments 
    """
    with open(filepath,'r') as fhandle:
        STR = fhandle.read()
        L_STR = STR.split('\n')
        return list( [ i for i in L_STR if comments_filter(i) ] )

def file_content2dict(filepath):
    D = {}
    LIST = get_list_from_file(filepath)
    for i in LIST:
        if try_substr(i,0,1)!='#' and i!='' and try_substr(i,0,1)!=' ':
            L = i.split('|')
            SHORT = L[0]
            SHORT = SHORT.lstrip().rstrip()
            PATH = L[1]
            PATH = PATH.lstrip().rstrip()
            D.update( { SHORT : PATH } )
    return dict(D)
    
# GLOBAL CLASSES
class memory_object(object):
    def __init__(self):
        self.states = {}
        self.memory = {}
    def default_states(self):
        self.states = {}
    def memorization(self,key):
        self.memory.update( { key: self.states } )
    def remembering(self,key):
        try:
            self.states = self.memory[ key ]
        except:
            self.default_states()
            
class living_object(object):
    def __init__(self):
        self.life = True
    def esc_call(self,x): 
        if not is_python_in_focus(): return None
        self.life = False
    def in_control(self):
        kbd.on_press_key('esc', self.esc_call)
        
class arrow_keys_interface_object(object):
    def __init__(self): 
        pass
    def display(self):
        os.system('cls')
        print('key pressed')
    def in_control(self):
        kbd.on_press_key('up', self.up_call)
        kbd.on_press_key('down', self.down_call)
        kbd.on_press_key('left', self.left_call)
        kbd.on_press_key('right', self.right_call)
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()

class toggle_object(object):
    def __init__(self,index,list_of_values):
        if index >= len(list_of_values):
            self.index = 0
        else:
            self.index = index
        self.list = list_of_values
    def toggle(self):
        self.index = self.index + 1
        if self.index >= len(self.list): self.index = 0
    def value(self):
        return self.list[ self.index ]
        
class file_explorer(living_object, memory_object, arrow_keys_interface_object):
    def __init__(self):
        living_object.__init__(self)
        memory_object.__init__(self)
        arrow_keys_interface_object.__init__(self)
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        self.memory = { self.states['current_dir'] : self.states }
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def print_long_pointed_list(self): 
        container = self.states['list_dir']
        position = self.states['pos']
        list_size = 15
        count = 0
        for i in container:
            if count > position+ list_size or count < position -list_size:
                if count == position + list_size + 1 or count == position - list_size - 1:
                    print('...')
            elif count == position:
                print( is_dirXfile(i), YL, '>', i , '<')
            else:
                print( is_dirXfile(i), ' ', WT, i, ' ')
            count = count + 1
    def display(self):  
        os.system('cls')
        os.system('whoami')
        total, used, free = shutil.disk_usage( os.getcwd() )
        print(WT + 'Diretorio :', self.states['current_dir']) 
        print(CY,'  Used Space :',used,'/',total,WT)
        print(CY,'  Free Space :',free,'/',total,WT)
        print(CY,'  Tamanho :', len( self.states['list_dir'] ), WT,'\n')
        self.print_long_pointed_list()
    def in_control(self):
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] > 0:
            self.states['pos'] = self.states['pos'] - 1
        self.display()
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] + 1 < len( self.states['list_dir'] ) :
            self.states['pos'] = self.states['pos'] + 1
        self.display()
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        OLD_DIR = self.states['current_dir']
        self.memorization( OLD_DIR )
        os.chdir('..')
        self.update()
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        if not isdir( self.states['list_dir'][ self.states['pos'] ] ): return None
        OLD_DIR = self.states['current_dir']
        self.memorization( OLD_DIR )
        try:
            os.chdir( self.states['list_dir'][ self.states['pos'] ] )
            self.update()
        except:
            os.chdir(OLD_DIR)
            self.update()
            print(RD+'\n ACCESS DENIED\n')
            os.system('pause')
        self.display()    
    def update(self):
        self.remembering( os.getcwd() )
    def default_states(self):
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        
class file_explorer31072020(file_explorer):
    def __init__(self):
        file_explorer.__init__(self)
    def esc_call(self,x):
        if not is_python_in_focus(): return None
        self.manually_dir()
        self.display()    
    def in_control(self):
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
        kbd.on_press_key('enter', self.enter_call)
    def manually_dir(self):
        OLD_DIR = os.getcwd()
        try:
            os.chdir( input('Diretorio :') )
            self.update()
        except:
            os.chdir( OLD_DIR )
            self.update()
    def enter_call(self,x):
        def text_editor_handle(ext):
            global L_EXT_TEXT_EDITOR
            if ext in L_EXT_TEXT_EDITOR:
                open_in_text_editor( self.states['list_dir'][ self.states['pos'] ] )
        def pdf_handle(ext):
            global L_EXT_PDF
            if ext in L_EXT_PDF:
                open_in_pdf_viewer( self.states['list_dir'][ self.states['pos'] ] )
        if not is_python_in_focus(): return None
        X, X_ext = get_ext( self.states['list_dir'][ self.states['pos'] ] )
        text_editor_handle(X_ext)
        pdf_handle(X_ext)

class menu_widget(arrow_keys_interface_object):
    """ 
    07082020 : NOT_TESTED : NOT_DEFINED
    menu_widget : item de uma lista com alguma funcionalidade especial que quando aperta right ele toma controle 
    
    > menu_widget * (S x T) Description ?
    ----------------------------------------------------------------------
    1) method [ .__repr__ ] : para imprimir uma string representado o item do menu
    2) method [ .in_control ] : quando aperta o botao de seta para direita o menu_widget deve tomar controle, isso deve ser definido dentro do menu_reader. Este metodo deve definir funcionalidades para o widget ativo.
    
    1) attribute [ .description ] : conteudo a ser retornado por __repr__
    ----------------------------------------------------------------------
    ...
    """
    def __init__(self, parent = None ,description='widget'):
        self.description = description
        self.parent = None
    def __repr__(self):
        return self.description
    def display(self):
        self.parent.display()    
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.parent.states['in_charge'] = self.parent
        self.parent.update()
        self.parent.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()

class file_explorer07082020(file_explorer,menu_widget):
    def __init__(self, directory):
        living_object.__init__(self)
        memory_object.__init__(self)
        arrow_keys_interface_object.__init__(self)
        OLD_DIR = os.getcwd()
        os.chdir(directory)
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        self.memory = { self.states['current_dir'] : self.states }
        os.chdir(OLD_DIR)
        
    def esc_call(self,x):
        if not is_python_in_focus(): return None
        self.parent.states['in_charge'] = self.parent
        self.parent.update()
        self.parent.display()    
    def in_control(self):
        os.chdir(self.states['current_dir'])
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
        kbd.on_press_key('enter', self.enter_call)
    def manually_dir(self):
        OLD_DIR = os.getcwd()
        try:
            os.chdir( input('Diretorio :') )
            self.update()
        except:
            os.chdir( OLD_DIR )
            self.update()
    def enter_call(self,x):
        def text_editor_handle(ext):
            global L_EXT_TEXT_EDITOR
            if ext in L_EXT_TEXT_EDITOR:
                open_in_text_editor( self.states['list_dir'][ self.states['pos'] ] )
        def pdf_handle(ext):
            global L_EXT_PDF
            if ext in L_EXT_PDF:
                open_in_pdf_viewer( self.states['list_dir'][ self.states['pos'] ] )
        if not is_python_in_focus(): return None
        X, X_ext = get_ext( self.states['list_dir'][ self.states['pos'] ] )
        text_editor_handle(X_ext)
        pdf_handle(X_ext)
    def display(self):  
        file_explorer.display(self)
        print(YL + '\npress esc to go back to parent menu'+WT)
        
class menu_widget(arrow_keys_interface_object):
    """ 
    07082020 : NOT_TESTED : NOT_DEFINED
    menu_widget : item de uma lista com alguma funcionalidade especial que quando aperta right ele toma controle 
    
    > menu_widget * (S x T) Description ?
    ----------------------------------------------------------------------
    1) method [ .__repr__ ] : para imprimir uma string representado o item do menu
    2) method [ .in_control ] : quando aperta o botao de seta para direita o menu_widget deve tomar controle, isso deve ser definido dentro do menu_reader. Este metodo deve definir funcionalidades para o widget ativo.
    
    1) attribute [ .description ] : conteudo a ser retornado por __repr__
    ----------------------------------------------------------------------
    ...
    """
    def __init__(self, parent = None ,description='widget'):
        self.description = description
        self.parent = None
    def __repr__(self):
        return self.description
    def display(self):
        self.parent.display()   
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.parent.states['in_charge'] = self.parent
        self.parent.update()
        self.parent.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()    
        
class menu_explorer(file_explorer31072020, menu_widget):
    def __init__(self, widget_iterable):
        file_explorer31072020.__init__(self)
        self.states = { 
            'current_dir' : os.getcwd(), 
            'pos': 0, 
            'list_dir': os.listdir(),
            'list_wdg': widget_iterable,
            'in_charge': self
            }
        self.parent = self
        self.description = RD+'Main Menu'
    def esc_call(self,x):
        if not is_python_in_focus(): return None
    def in_control(self):
        file_explorer31072020.in_control(self)
    def enter_call(self,x):
        if not is_python_in_focus(): return None
    def default_states(self):
        pass
    def update(self):
        kbd.unhook_all()
        self.states['in_charge'].in_control()
    def print_long_pointed_list(self): 
        container = self.states['list_wdg']
        position = self.states['pos']
        list_size = 15
        count = 0
        for i in container:
            if count > position+ list_size or count < position -list_size:
                if count == position + list_size + 1 or count == position - list_size - 1:
                    print('...')
            elif count == position:
                print( YL, '>', i , YL+'<')
            else:
                print( ' ', WT, i, ' ')
            count = count + 1
    def display(self):  
        os.system('cls')
        print(WT + 'Diretorio :', self.states['current_dir']) 
        print(CY,'  Tamanho :', len( self.states['list_wdg'] ), WT,'\n')
        print(self.states['in_charge'],'\n')
        self.update()
        self.print_long_pointed_list()
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] > 0:
            self.states['pos'] = self.states['pos'] - 1
        self.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] + 1 < len( self.states['list_wdg'] ) :
            self.states['pos'] = self.states['pos'] + 1
        self.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.states['in_charge'] = self.parent
        self.update()
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        self.states['in_charge'] = self.states['list_wdg'][ self.states['pos'] ]
        self.update()
        self.states['in_charge'].display()

# GLOBAL FUNCTIONS [ file explorer ]
def file_explorer_main_thread(obj): # main_thread
    obj.in_control()
    # obj.manually_dir()
    obj.display()
    while obj.life:
        sleep(1)

def file_explorer_main(): # main
    if platform.system()!='Windows': return None # GUARD [ Windows Systems ]
    widgets = []
    for element in get_partition_list():
        if element=='G:\\': continue
        obj = file_explorer07082020(element)
        obj.description = CY+'File Explorer :'+element
        widgets.append( obj )
    E = menu_explorer(widgets)
    for i in widgets: i.parent = E
    THR_obj = thr.Thread( target = file_explorer_main_thread, args=(E,) )
    THR_obj.start()

# GLOBAL VARS [ Pomodoro and RPG status and settings.config file ]
CONFIG_DICT = file_content2dict('settings.config')
POMO_MIN_SEC = 60* int(CONFIG_DICT['POMO_MIN_SEC']) # 60*45
POMO_MIN_SEC_desc = '(45 min)'
HP = int(CONFIG_DICT['HP'])
MP = int(CONFIG_DICT['MP'])

# GLOBAL VARS [ Debug ]
flag = RD+"RED FLAG"

# GLOBAL VARS [ Messages and Strings ]
LINE_str = "-----------------------------------------------------------------------------"
PROG_NAME_str = "\n Command Line Interface [ BrainWasher ] : { 24082020 }"
PROG_DESC_str = "    Interface de Comandos em Python"

COM_str0 = """"""

COM_NAV_geral = """"""

COM_TEXT_str = """"""

# GLOBAL VARS [ Directories and Path ]
project_dr = os.getcwd() + '\\'
dir_origem = project_dr
os.chdir(project_dr)
listDir = os.listdir()

# --------------------------------------------------------------------------------
# CLASSES ABSTRATAS PRINCIPAIS
# --------------------------------------------------------------------------------

class Interface(object): # PROIBIDO MODIFICAR 06072020
    """ Classe Generica de Interface de Leitura e Escrita em Dicionarios """
    def __init__(self,filename=None,main_obj=None):
        self.states = {'filename':filename, 'auto interface info':True}
        self.desc = ''
    
    # Interface > Funcoes > Auxiliar
    def __flag(self): # Debug : Mostra a Localizacao do Erro
        print( YL+'Classe : Interface' )
        print( print_dict(self.states) )
        print( self.desc )
    def print_dict(self):
        print()
        obj = self.states
        for key in obj.keys():
            print( 3*' ',key, ':', str( obj[key] ) )
        print()
    def help_c(self):
        print(WT+LINE_str)
        print(YL+COM_str0)
    def short_desc(self):
        return YL+self.desc
    def write_str(self,filename,obj):
        fhandle = open(filename,'w')
        fhandle.write( str(obj) )
        fhandle.close()
    def try_saveBy_name(self,write,filename,state_name):
        if filename=='': # filename nao especificado no comando
            try:
                write(self.states[state_name],self.states)
            except: # input the filename
                try:
                    self.states[state_name] = input('Nome do Arquivo : ')
                    write(self.states[state_name],self.states)
                except:
                    print( RD+'Nao Foi Possivel Salvar o Arquivo' )
                    self.__flag()
        else: # filename especificado
            try:
                self.states[state_name]=filename
                write(self.states[state_name],self.states)
            except:
                print( RD+'Nao Foi Possivel Salvar o Arquivo' )
                self.__flag()
    def read_lit(self,filename):
        file_obj = open(filename,'r')
        RET = ast.literal_eval( file_obj.read() )
        file_obj.close()
        return RET
    def try_loadBy_name(self, filename):
        import ast
        try:
            return self.read_lit(filename)
        except:
            print('Nao Foi Possivel Carregar o Arquivo')
            self.__flag()
    
    # Interface > Funcoes > Principais        
    def save( self, string='' ):
        self.try_saveBy_name( 
            write = self.write_str, 
            filename = string,
            state_name = 'filename'
            )
    def load(self):
        self.states.update( self.try_loadBy_name(
            filename = self.states['filename']
            ) )
    
    # Interface > Funcoes > Principais > Comandos
    def commands(self,input_str,main_obj):
        # print(try_substr(input_str,'all',5))
        if input_str=='@exit':
            #if main_obj==self:
            return True
        elif input_str=='@help':
            self.help_c()
            return False
        elif input_str=='@jump':
            print(50*'\n')
            return False
        elif try_substr(input_str,0,5)=='@save':
            filename = try_substr(input_str,6,'all')
            self.save(filename)
            return False
        elif try_substr(input_str,0,5)=='@load':
            self.load()
            return False
        elif input_str == '@interface info':
            print(self.states)
            return False
        elif input_str == '@listdir':
            print()
            for k in os.listdir():
                print( GR,k)
            print()
            return False
        else:
            return False
    def __repr__(self):
        return self.desc

class VerticalOrientedInterface(Interface): # PROIBIDO MODIFICAR 06072020
    """ Interface Orientada : possui referencias de Outras Interfaces podendo ser utilizado para navegar entre interfaces
        
        1 - Temos a Interface de Origem que e a Interface de Retorno
        2 - Temos uma opcao de subinterface inicialmente vazia para poder permitir a criacao de subinterfaces
        3 - E uma classe abstrata, serve para organizar as classes operacionais
    
    """
    def __init__(self,filename=None,dad_ref=None,main_obj=None):
        Interface.__init__(self,filename,main_obj)
        self.network = { 'Interface de Origem' : dad_ref }
        self.listdir = os.listdir() #listDir
        self.states.update( {'return?':False} )
        
    # VerticalOrientedInterface > Comandos > Auxiliares
    
    # callbacks de input de keyboard
    def up_callback(self,head,X):
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def down_callback(self,head,X):
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def left_callback(self,head,X):
        head.head = self.network['Interface de Origem']
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def right_callback(self,head,X):
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
            
    def __flag(self):
        print( YL+'Classe : VerticalOrientedInterface')
        print( print_dict(self.states) )
        print( self.desc )
    
    def comm_new_child_interface(self,child_filename):
        """ Cria uma Interface de NAvegacao Filha """
        Child = VerticalOrientedInterface(
            filename = child_filename, 
            dad_ref  = self
            )
        self.network.update( { child_filename : Child } )
    def comm_del_child_interface(self,child_filename):
        try:
            var = self.network[child_filename]
            self.network[child_filename] = None
            del var
            self.network.pop(child_filename)
            print('Objeto Deletado')
        except:
            print('Objeto Nao Existe')
            self.__flag()
    def comm_show_network(self):
        print( '\n'+GR+'[ Network ] :' )
        for key in self.network.keys():
            print(2*' ',GR,key )
        print()
        
    # VerticalOrientedInterface > Comandos > Principal
    def rpg_status_update(self,main_obj):
        pass
    def commands(self,input_str,main_obj):
        # print(try_substr(input_str,'all',5))
        if input_str=='@exit':
            if self.desc=='INTERFACE PRINCIPAL':
                return True
            else:
                self.states.update( { 'return?':True } )
                return False
        elif input_str=='@help':
            self.help_c()
            print(GR+COM_NAV_geral)
            return False
        elif input_str=='@jump':
            print(50*'\n')
            return False
        elif try_substr(input_str,0,5)=='@save':
            filename = try_substr(input_str,6,'all')
            self.save(filename)
            return False
        elif try_substr(input_str,0,5)=='@load':
            self.load()
            return False
        elif try_substr(input_str,0,len('@child interface') ) == '@child interface':
            self.comm_new_child_interface( try_substr(input_str,len('@child interface')+1, 'all' ) )
            return False
        elif try_substr(input_str,0,len('@del child interface') ) == '@del child interface':
            self.comm_del_child_interface( try_substr(input_str,len('@del child interface')+1, 'all' ) )
            return False
        elif input_str=='@network':
            self.comm_show_network()
        elif input_str == '@interface info':
            print(self.states)
            return False
        else:
            return Interface.commands(self,input_str,main_obj)

class HeadInterface(Interface): # PROIBIDO MODIFICAR 06072020
    """ E uma interface que observa uma interface orientada, e usada pela funcao main para interpretar os comandos
        
        1 - Tem o comando para mudar sua posicao para uma interface dentro da interface de navegacao
    """
    def __init__(self,filename, oriented_interface,main_obj=None):
        Interface.__init__(self,filename,main_obj)
        self.head = oriented_interface
    def __flag(self):
        print( YL+'Classe : HeadInterface') 
        print( print_dict(self.states) )
        print( self.desc )
    def commands(self,input_str,main_obj):
        if input_str == '@origem':
            save_head = self.head
            self.head = self.head.network['Interface de Origem']
        elif try_substr(input_str,0,len('@goto') ) == '@goto':
            try:
                self.head = self.head.network[ try_substr(input_str,len('@goto')+1, 'all' ) ]
            except:
                self.head.comm_show_network()
            return False
        elif input_str == '@teste':
            try:
                teste()
            except:
                print(RD+'ERRO' )
            return False
        else:
            return self.head.commands(input_str,main_obj)
        
# ---------------------------------------------------------------------------------
# CLASSES de APLICACAO
# ---------------------------------------------------------------------------------

class TextInterface(VerticalOrientedInterface): # PROIBIDO MODIFICAR 07072020
    """ Tem um arquivo de texto que pode ser lido e manipulado, alem do arquivo de estados """
    def __init__(self,filename,dad_ref,main_obj,txt_dir=project_dr):
        VerticalOrientedInterface.__init__(self,filename,dad_ref,main_obj)
        self.desc = 'TEXT INTERFACE'
        self.states.update( { 'content': """ ... """, 'exist text filename': False }  )
        self.txt_dir = txt_dir
        
    def print_dict(self):
        print()
        print( 'Arquivo de Estados da Interface : ' , self.states['filename'] )
        print( 'conteudo : ' , self.states['exist text filename'] )
        try:
            print( 'Arquivo do Texto Selecionado : ', self.states['text filename'] )
        except:
            print(RD+'Selecione um Arquivo de Texto com @load ou @load=' + WT )
        print()    
    def comm_select_filename(self,filename):
        self.states.update( { 'exist text filename': True, 'text filename':filename } )
        
    def comm_extern_editor(self):
        import sys, os
        #print( main_obj.states['default text editor'] +' '+self.states['text filename'] )
        # self.states['Interface de Origem'].states['default text editor'] +' '+
        # print( self.network['Interface de Origem'] ) 
        os.system( '"'+self.network['Interface de Origem'].states['default text editor'] +'" '+ self.states['text filename'] )
        
    def show_content(self):
        print(WT+'\n [ CONTEUDO ] : { ' + RD+'Conteudo do Arquivo de Texto' + WT+' }' )
        print(WT+LINE_str)
        print(GR+ self.states['content'] )
        print()
    def comm_create_text_file(self,filename):
        os.chdir(self.txt_dir)
        self.states.update( { 'text filename':filename, 'exist text filename': True } )
        fhandle = open(filename,'w')
        fhandle.write( self.states['content'] )
        fhandle.close()
        self.comm_load_text_file( filename )
        os.chdir(project_dr)
        #print(filename)
    def comm_create_half_text_files(self):
        os.chdir(self.txt_dir)
        UP_RHALPH = self.states['text filename'] + '0'
        LW_RHALPH = self.states['text filename'] + '1'
        L1, L2 = half_sublists( self.states['content'].split('\n') )
        with open(UP_RHALPH,'w') as fhandle:
            fhandle.write( '\n'.join(L1) )
        with open(LW_RHALPH,'w') as fhandle:
            fhandle.write( '\n'.join(L2) )
        os.chdir(project_dr)
    def save(self):
        os.chdir(self.txt_dir)
        if self.states['exist text filename']:
            fhandle = open( self.states['text filename'] ,'w')
            fhandle.write( self.states['content'] )
            fhandle.close()
        os.chdir(project_dr)
    def comm_load_text_file(self,filename):
        os.chdir(self.txt_dir)
        try:
            file_obj = open(filename,'r')
            RET = file_obj.read()
            file_obj.close()
            self.states.update( {'content': RET,'text filename' : filename, 'exist text filename': True } )
        except:
            self.states.update( { 'exist text filename': False } )
            print('Nao Foi Possivel Carregar o Arquivo')
        os.chdir(project_dr)
    # TextInterface > Funcoes > Comandos
    def commands(self, input_str,main_obj):
        if input_str == '@content':
            self.show_content()
            return False
        elif input_str=='@save':
            self.save()
        elif try_substr(input_str,0,len('@create')) == '@create':
            if try_substr( input_str, len('@create')+1,'all' )!='':
                self.comm_create_text_file( try_substr( input_str, len('@create')+1,'all' ) )
                #self.states.update( {'content':' ... '} )
                return False
            else:
                return False
        elif try_substr(input_str,0,len('@split')) == '@split':
            if not self.states['exist text filename']: return False
            self.comm_create_half_text_files()
            return False
        elif try_substr( input_str, 0,len('@load=') ) == '@load=':
            os.chdir(self.txt_dir)
            for i in range( len( os.listdir() ) ):
                print(i,' : ' ,GR, os.listdir()[i]  )
            print()
            try:
                X = try_substr(input_str, len('@load='), 'all')
                Y = os.listdir()
                self.comm_load_text_file( Y[ int(X) ] )
                os.chdir(project_dr)
                return False
            except:
                print(RD+ ' Escolha um Numero ' )
                os.chdir(project_dr)
                return False
            os.chdir(project_dr)
        elif try_substr(input_str,0,len('@load')) == '@load':
            os.chdir(self.txt_dir)
            if try_substr( input_str, len('@load')+1,'all' )!='':
                self.comm_load_text_file( try_substr( input_str, len('@load')+1,'all' ) )
            else:
                print()
                for i in os.listdir():
                    print(i)
                print()
                if self.states['exist text filename']:
                    try:
                        self.comm_load_text_file( self.states['text filename'] )
                    except:
                        print(flag)
            os.chdir(project_dr)            
            return False
        elif try_substr(input_str,0,len('@select') ) == '@select':
            if True: return False
            os.chdir(self.txt_dir)
            try:
                if try_substr( input_str , len('@select')+1, 'all' )=='':
                    print()
                    for i in os.listdir():
                        print(i)
                    print()
                else:
                    self.comm_select_filename( try_substr( input_str , len('@select')+1, 'all' ) )
                os.chdir(project_dr)    
                return False
            except:
                print('Escreva um Nome Correto')
                os.chdir(project_dr)
                return False
        elif input_str=='@editor':
            os.chdir(self.txt_dir)
            try:
                self.comm_extern_editor()
                if self.states['exist text filename']: # 11082020
                    try:
                        self.comm_load_text_file( self.states['text filename'] )
                    except:
                        print(flag)
            except:
                print('Selecione um Arquivo com @select')
            os.chdir(project_dr)    
        elif input_str=='@help':
            self.help_c()
            print(GR+COM_TEXT_str)
            return False
        else:
            os.chdir(self.txt_dir)
            X = VerticalOrientedInterface.commands(self,input_str,main_obj)
            os.chdir(project_dr)
            return X

class add_cell_header_TextInterface(TextInterface): # PROIBIDO MODIFICAR 07072020
    def __init__(self,filename, dad_ref,main_obj,txt_dir):
        TextInterface.__init__(self, filename, dad_ref,main_obj,txt_dir)
        self.desc = 'ADD CELL TEXT INTERFACE'
    
    def add_cell_header(self,cell_info):
        #print(self.states['content'])
        X = self.states['content']
        self.states['content'] = X + 2*'\n' + '>>>>> ' + cell_info + '\n' + LINE_str + 3*'\n' + LINE_str
        self.save()
        
    def commands(self,input_str,main_obj):
        #print( try_substr ( input_str,len(input_str)-1,'all') )
        if try_substr ( input_str,len(input_str)-1,'all')=='!':
            self.add_cell_header(try_substr(input_str,0,len(input_str)-1))
            return False
        elif input_str=='@help':
            self.help_c()
            print(GR+"""
        Comandos [ de Interface de Manipulacao de Texto ] :
            
            1 - Esta interface adiciona informacoes em arquivo de texto
                formatado.
        
        INFORMACAO ! : finalizar um input com ! ira adicionar no arquivo de 
            texto o que estiver escrito antes
        
1 -         @origem : Retorna para Origem
2 -         @network : Mostra as opcoes da rede de Navegacao de Interfaces
3 -         @content : mostra o conteudo do arquivo de texto selecionado
4 -         @goto NOME : Vai para uma interface cujo nome e NOME           
5 -         @create NOME.txt : cria um arquivo de texto
6 -         @editor : Abre o editor externo padrao para .txt
7 -         @load : Mostra uma lista de nomes de arquivos na pasta corrente
8 -         @load NOME : Abre o arquivo NOME
9 -         @load= : Mostra uma lista numerada dos arquivos na pasta corrente
10 -        @load=NUMERO : Abre o arquivo correspondente ao numero
11 -        @select NOME: Apenas muda o nome do arquivo texto, 
                nao muda o conteudo, requer @load          
            """)
        else:
            return TextInterface.commands(self,input_str,main_obj)

class inventoryTextInterface(add_cell_header_TextInterface): # PROIBIDO MODIFICAR 08072020
    """"""
    def __init__(self, filename, dad_ref, main_obj, txt_dir):
        add_cell_header_TextInterface.__init__(self, filename, dad_ref,main_obj,txt_dir)
        self.desc = 'INVENTORY INTERFACE'
        self.states['exist dict'] = False
        self.states['dict'] = {}
        self.title = '# Inventario : { ' + str(date.today()) + ' }'
    def teste(self):
        print(flag,'Este eh o teste')
        print(date.today())
    
    # inventoryTextInterface > funcoes > auxiliares
    def print_dict_info(self):
        D = self.states['dict']
        K = D.keys()
        try:
            print()
            
            for i in K:
                if D[i]<=5:
                    print(i,':',RD,D[i])
                elif D[i]>5 and D[i] <=10:
                    print(i,':',YL, D[i] )
                else:
                    print(i, ':', GR, D[i])
            print()
        except:
            print()
    def add_cell_header(self, cell_info):
        X = self.states['content']
        self.states['content'] = X + '\n' + '' + cell_info # + LINE_str + 3*'\n' + LINE_str
        self.save()           
    def content2dict(self): # calmala
        D = {}
        for i in self.content2list():
            idx = 0 # count_ast(i)
            if try_substr(i,0,1)!='#' and idx<len(i) :
                if idx == 0 :
                    D.update( { i[idx:] : idx } )
                else:
                    D.update( { i[idx+1:] : idx } )
        return D
    def dict2content(self,dictionary):
        self.states['content'] = self.title + '{ ' + self.states['text filename'] + ' }\n'
        X = self.states['content']
        for J in dictionary.keys():
            if dictionary[J]==0:
                X = X +J+'\n' 
            else:
                X = X + dictionary[J]*'*'+' '+J+'\n' 
        self.states['content'] = X
    def content2list(self):
        X = self.states['content']
        X_list = X.split('\n')
        return X_list
    
    # inventoryTextInterface > funcoes > principais
    def save(self): ##
        os.chdir(self.txt_dir)
        
        if self.states['exist text filename'] and self.states['exist dict']:
            self.dict2content( self.states['dict'] )
            fhandle = open( self.states['text filename'] ,'w')
            fhandle.write( self.states['content'] )
            fhandle.close()
            
            
        #Interface.save(self)
        
        os.chdir(project_dr)
    def comm_load_text_file(self,filename):
        os.chdir(self.txt_dir)
        try:
            file_obj = open(filename,'r')
            RET = file_obj.read()
            file_obj.close()
            self.states.update( {'content': RET,'text filename' : filename, 'exist text filename': True } )
        except:
            self.states.update( { 'exist text filename': False } )
            print('Nao Foi Possivel Carregar o Arquivo')
        try:
            self.states['dict'].update( self.content2dict() )
            self.states['exist dict'] = True
            
            # print_dict(self.states) ##
            #print_dict(self.states['dict']) ## 
            self.print_dict_info()
            # print(self.states['dict']) ##
            
        except:
            print(flag,'DEU MERDA')
            self.states['exist dict'] = False
        os.chdir(project_dr)        
        
    # inventoryTextInterface > funcoes > comandos    
    def commands(self, input_str, main_obj):
        if input_str=='@teste':
            try:
                self.teste()
            except:
                print(flag, 'teste errado')
        elif try_substr(input_str,0,len('@create')) == '@create':
            if try_substr( input_str, len('@create')+1,'all' )!='':
                self.comm_create_text_file( try_substr( input_str, len('@create')+1,'all' ) )
                #self.states.update( {'content':' ... '} )
                return False
            else:
                return False
        elif input_str=='@save':
            self.save()
        elif try_substr( input_str, 0,len('@load=') ) == '@load=':
            os.chdir(self.txt_dir)
            for i in range( len( os.listdir() ) ):
                print(i,' : ' ,GR,os.listdir()[i] )
            print()
            try:
                X = try_substr(input_str, len('@load='), 'all')
                Y = os.listdir()
                self.comm_load_text_file( Y[ int(X) ] )
                os.chdir(project_dr)
                return False
            except:
                print(RD+ ' Escolha um Numero ' )
                os.chdir(project_dr)
                return False
            os.chdir(project_dr)
        elif try_substr(input_str,0,len('@load')) == '@load':
            os.chdir(self.txt_dir)
            if try_substr( input_str, len('@load')+1,'all' )!='':
                self.comm_load_text_file( try_substr( input_str, len('@load')+1,'all' ) )
            else:
                print()
                for i in os.listdir():
                    print(i)
                print()
                if self.states['exist text filename']:
                    try:
                        self.comm_load_text_file( self.states['text filename'] )
                    except:
                        print(flag)
            os.chdir(project_dr)            
            return False
        elif input_str=='@help':
            self.help_c()
            print(GR+"""
        Comandos [ de Interface de Manipulacao de Texto ] :
            
            1 - Esta interface adiciona informacoes em arquivo de texto
                formatado.
        
        INFORMACAO ! : finalizar um input com ! ira adicionar no arquivo de 
            texto o que estiver escrito antes
        
1 -         @origem : Retorna para Origem
2 -         @network : Mostra as opcoes da rede de Navegacao de Interfaces
3 -         @content : mostra o conteudo do arquivo de texto selecionado
4 -         @goto NOME : Vai para uma interface cujo nome e NOME           
5 -         @create NOME.txt : cria um arquivo de texto
6 -         @editor : Abre o editor externo padrao para .txt
7 -         @load : Mostra uma lista de nomes de arquivos na pasta corrente
8 -         @load NOME : Abre o arquivo NOME
9 -         @load= : Mostra uma lista numerada dos arquivos na pasta corrente
10 -        @load=NUMERO : Abre o arquivo correspondente ao numero
11 -        @select NOME: Apenas muda o nome do arquivo texto, 
                nao muda o conteudo, requer @load          
            """)    
        else:
            return add_cell_header_TextInterface.commands(self,input_str, main_obj)

class brainWasherInterface(inventoryTextInterface): # PROIBIDO MODIFICAR 09072020
    """"""
    def __init__(self, filename, dad_ref, main_obj, txt_dir):
        inventoryTextInterface.__init__(self, filename, dad_ref,main_obj,txt_dir)
        self.desc = 'BRAINWASHER INTERFACE' #'INVENTORY INFO INTERFACE' 
        self.states['exist dict'] = False
        self.states['dict'] = {}
        self.title = '# Inventario [ de Informacoes ] : { ' + str(date.today()) + ' }'
        self.main_obj = main_obj
    def teste(self):
        print(flag,'Este eh o teste')
        
        print(date.today())
    
    # brainWasherInterface > funcoes > auxiliares
    def rpg_status_update(self,main_obj):
        if POMO_MIN_SEC - main_obj.time_shift <0: # SP BAIXO ~ Comida
            while input('\n\t Seu SP esta baixo, deveria comer alguma coisa ...')!='comi':
                print('\n \t \t Coma algo ! (digite : comi)')
            main_obj.time_shift = 0
            main_obj.time_init = time()
        elif False: # HP BAIXO ~ Heal de MP
            pass
        elif False: # MP BAIXO ~ Comida
            pass
        else:
            main_obj.time_shift = time() - main_obj.time_init
            if POMO_MIN_SEC - main_obj.time_shift>=0:
                print()
                #print( status(10,10,'HP', red) )
                print( status(POMO_MIN_SEC - main_obj.time_shift, POMO_MIN_SEC,'POMODORO '+POMO_MIN_SEC_desc, CY) )
                #print( status(10,10,'MP',green) )
    def print_dict_info(self):
        D = self.states['dict']
        K = D.keys()
        print()
        for i in K:
            if D[i]<=5:
                print(i,':',RD,D[i], WT)
            elif D[i]>5 and D[i] <=10:
                print(i,':',YL, D[i], WT )
            else:
                print(i, ':', GR, D[i], WT )
        print()
    def add_cell_header(self, cell_info):
        X = self.states['content']
        self.states['content'] = X + '\n' + '' + cell_info + ' ;' # + LINE_str + 3*'\n' + LINE_str
        self.save()
    def uniform_study(self,repetition_number=50,nivel=20):
        for i in range(repetition_number):
            try:
                self.rpg_status_update(self.main_obj)
            except:
                pass
            print('\nPERGUNTA ['+YL+' SORTEIO UNIFORME '+ WT + '] :\n'+LINE_str)
            N = self.random_info(nivel)
            if N == None: break
            print( 'MODO [ ' + GR+'ESTUDO'+' ] : { ', YL+'Nro de Sorteios :', RD + str(repetition_number-i)  ,' }'  )
            print(WT+LINE_str)
            INP = input(' [ ? ou G ] >>>>> ')
            os.system('CLS')
            if self.states['dict'][N]!=0:
                if INP == '?':
                    self.states['dict'][N] = self.states['dict'][N] - 1
                elif INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
            else:
                if INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
            X = self.states['dict']
            
            print()
            
            self.print_dict_info()
            # print_dict(self.states['dict'])
        self.save()
    def random_info(self,nivel): ##
        if self.states['exist dict']:
            K = list( self.states['dict'].keys() )
            L = len( K )
            idx = int(randint(0,L-1))
            counter = 0
            while self.states['dict'][ K[idx] ] > nivel and counter < 50:
                idx = int(randint(0,L-1))
                counter = counter + 1
            if counter == 50 : return None
            print(2*'\n')
            print(4*' ' + K[ idx ] )
            print(2*'\n')
            return K[ idx ]
        return None
    def content2dict(self): # calmala
        D = {}
        for i in self.content2list():
            idx = count_ast(i)
            if idx<len(i) and try_substr(i,0,1)!='#':
                if idx == 0 :
                    D.update( { i[idx:] : idx } )
                else:
                    D.update( { i[idx+1:] : idx } )
        return D
    def dict2content(self,dictionary):
        self.states['content'] = self.title + '{ ' + self.states['text filename'] + ' }\n'
        
        X = self.states['content']
        for J in dictionary.keys():
            if dictionary[J]==0:
                X = X +J+'\n' 
            else:
                X = X + dictionary[J]*'*'+' '+J+'\n' 
        self.states['content'] = X
    def content2list(self):
        X = self.states['content']
        X_list = X.split('\n')
        return X_list
    
    # brainWasherInterface > funcoes > principais
    def save(self): ##
        os.chdir(self.txt_dir)
        
        if self.states['exist text filename'] and self.states['exist dict']:
            self.dict2content( self.states['dict'] )
            fhandle = open( self.states['text filename'] ,'w')
            fhandle.write( self.states['content'] )
            fhandle.close()
            
        #Interface.save(self)
        
        os.chdir(project_dr)
    def comm_load_text_file(self,filename):
        os.chdir(self.txt_dir)
        try:
            file_obj = open(filename,'r')
            RET = file_obj.read()
            file_obj.close()
            self.states.update( {'content': RET,'text filename' : filename, 'exist text filename': True } )
        except:
            self.states.update( { 'exist text filename': False } )
            print('Nao Foi Possivel Carregar o Arquivo')
        try:
            self.states['dict'] = {}
            self.states['dict'].update( self.content2dict() )
            self.states['exist dict'] = True
            
            # print_dict(self.states) ##
            #print_dict(self.states['dict']) ## 
            self.print_dict_info()
            # print(self.states['dict']) ##
            
        except:
            print(flag,'DEU MERDA')
            self.states['exist dict'] = False
        os.chdir(project_dr)        
        
    # brainWasherInterface > funcoes > comandos    
    def commands(self, input_str, main_obj):
        if input_str=='@teste':
            try:
                self.teste()
            except:
                print(flag, 'teste errado')
        elif try_substr(input_str,0, len('@start=(') ) == '@start=(':
            X = try_substr(input_str, len('@start=('), 'all' )[:-1]
            Y = X.split(',')
            try:
                self.uniform_study( int(Y[0]) , int(Y[1]) )
            except:
                print(RD+'Coloque um Numero')
        elif try_substr(input_str,0, len('@start=') ) == '@start=':
            X = try_substr(input_str, len('@start='), 'all' )
            try:
                self.uniform_study( int(X) )
            except:
                print(X)
                print(RD+'Coloque um Numero')
        elif input_str == '@start':
            self.uniform_study()
        elif try_substr(input_str,0,len('@create')) == '@create':
            self.states.update( {'content':' ... '} )
            if try_substr( input_str, len('@create')+1,'all' )!='':
                self.comm_create_text_file( try_substr( input_str, len('@create')+1,'all' ) )
                
                return False
            else:
                return False
        elif input_str=='@save':
            self.save()
        elif try_substr( input_str, 0,len('@load=') ) == '@load=':
            os.chdir(self.txt_dir)
            for i in range( len( os.listdir() ) ):
                print(i,' : ' ,GR,os.listdir()[i] )
            print()
            try:
                X = try_substr(input_str, len('@load='), 'all')
                Y = os.listdir()
                self.comm_load_text_file( Y[ int(X) ] )
                os.chdir(project_dr)
                return False
            except:
                print(RD+ ' Escolha um Numero ' )
                os.chdir(project_dr)
                return False
            os.chdir(project_dr)
        elif try_substr(input_str,0,len('@load')) == '@load':
            os.chdir(self.txt_dir)
            if try_substr( input_str, len('@load')+1,'all' )!='':
                self.comm_load_text_file( try_substr( input_str, len('@load')+1,'all' ) )
            else:
                OLD_DIR = os.getcwd()
                os.chdir('..')
                proc = sbp.Popen('python brain_load_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE)
                proc.wait()
                with open('data_transfer','r') as fhandle:
                    X = fhandle.read()
                    if not os.path.isdir( X ):
                        self.comm_load_text_file( os.path.join( X ) )
                proc.kill()
                os.chdir(OLD_DIR)
                    
            os.chdir(project_dr)            
            return False
        elif try_substr(input_str,0,len('@reload')) == '@reload':
            if self.states['exist text filename']:
                try:
                    self.comm_load_text_file( self.states['text filename'] )
                except:
                    print(RD+'ERRO')
        
        elif input_str=='@reset study':
            try:
                for i in self.states['dict'].keys():
                    self.states['dict'][i] = 0
                    self.save()
            except:
                print(flag, 'erro!')
            return False
        elif input_str=='@help':
            self.help_c()
            print(GR+"""
            """)     
        else:
            return inventoryTextInterface.commands(self,input_str, main_obj)
        
class bookshelfInterface(inventoryTextInterface): # PROIBIDO MODIFICAR 09072020
    def __init__(self, filename, dad_ref, main_obj, txt_dir):
        inventoryTextInterface.__init__(self, filename, dad_ref, main_obj, txt_dir)
    def content2dict(self): # calmala
        D = {}
        for i in self.content2list():
            if try_substr(i,0,1)!='#' and i!='' and try_substr(i,0,1)!=' ':
                L = i.split('|')
                SHORT = L[0]
                PATH = L[1]
                D.update( { SHORT.rstrip() : PATH.lstrip() } )
        return D
    def dict2content(self,dictionary):
        self.states['content'] = self.title + '{ ' + self.states['text filename'] + ' }\n'
        X = self.states['content']
        for J in dictionary.keys():
            if dictionary[J]==0:
                X = X +J+'\n' 
            else:
                X = X + dictionary[J]*'*'+' '+J+'\n' 
        self.states['content'] = X    
    def commands(self, input_str, main_obj):
        if input_str == '@shortcuts':
            print('Biblioteca : \n')
            for i in self.states['dict'].keys():
                print( GR,i )
                print( len(i)*'-' )
                print('\t' ,YL,self.states['dict'][i] )
            print()
            return False
        elif input_str=='@save':
            return False
        elif input_str=='@help':
            if True: return False
            self.help_c()
            print(GR+"""
        Comandos [ Biblioteca de Atalhos de Livros ] :
            
            1 - Organizar atalhos de livros para ser usado com o comando @pdf=
            2 - Formato:
                ATALHO | ENDERECO_DO_ARQUIVO
        
        INFORMACAO ! : finalizar um input com ! ira adicionar no arquivo de 
            texto o que estiver escrito antes
        
1 -         @exit ou @origem : Retorna para Origem
2 -         @network : Mostra as opcoes da rede de Navegacao de Interfaces
3 -         @content : mostra o conteudo do arquivo de texto selecionado
4 -         @create NOME.txt : cria um arquivo de texto
5 -         @editor : Abre o editor externo padrao para .txt para editar
                os shortcuts
6 -         @load : Carrega o arquivo com os shortcuts
7 -         @shortcuts : Mostra os livros e seus atalhos para serem usados 
                com o comando @pdf=
            """)
            return False
        elif input_str=='@add':
            proc = sbp.Popen('python add_bookshortcut_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE)
            proc.wait()
            with open('data_transfer','r') as fhandle:
                X = fhandle.read()
            proc.kill()
            if X!='':
                print( CY+' Write the shortcut for :\n\n\t'  + GR+ X +CY+'\n\n (otherwise just press enter)' + WT)
                Y = input('>>> ')
            else:
                Y = ''
            if Y!='':
                with open('books\\books_shortcuts09072020','a') as fhandle:
                    fhandle.write( '\n'+ Y+' | "'+X+'"' )
                self.comm_load_text_file( self.states['text filename'] )
            return False
        else:
            return inventoryTextInterface.commands(self,input_str, main_obj)
    def __repr__(self):
        STRING = GR+"""
        Comandos [ Biblioteca de Atalhos de Livros ] :
            
            1 - Organizar atalhos de livros para ser usado com o comando @pdf=
            2 - Formato:
                ATALHO | ENDERECO_DO_ARQUIVO
        
        INFORMACAO ! : finalizar um input com ! ira adicionar no arquivo de 
            texto o que estiver escrito antes
        
1 -         @origem : Retorna para Origem
2 -         @network : Mostra as opcoes da rede de Navegacao de Interfaces
3 -         @content : mostra o conteudo do arquivo de texto selecionado
4 -         @create NOME.txt : cria um arquivo de texto
5 -         @editor : Abre o editor externo padrao para .txt
6 -         @load : Mostra uma lista de nomes de arquivos na pasta corrente
7 -         @load NOME : Abre o arquivo NOME
8 -         @load= : Mostra uma lista numerada dos arquivos na pasta corrente
9 -         @load=NUMERO : Abre o arquivo correspondente ao numero        
10 -        @shortcuts : Mostra os livros e seus atalhos para serem usados 
                com o comando @pdf=
11 -        @add : Adiciona shortcut usando file explorer              
            """
        return STRING
        
class rpgBrainwasher(brainWasherInterface):
    def __init__(self, filename, dad_ref, main_obj, txt_dir):
        brainWasherInterface.__init__(self,filename, dad_ref, main_obj, txt_dir)
        self.__X = (True,False)
        self.show_tips = toggle_object(0,self.__X)
        self.show_dict_content = toggle_object(1,self.__X)
        
    def progress_bar(self, value ,upper_bound):
        X = int(floor( value*500./upper_bound ))
        return X
    def rpg_status_update(self,main_obj):
        if POMO_MIN_SEC - main_obj.time_shift <0: # SP BAIXO ~ Comida
            while input('\n\t Seu SP esta baixo, deveria comer alguma coisa, deveria correr um pouco, deveria relaxar um pouco ...')!='ja fiz tudo isso':
                print('\n \t \t Coma algo ! (digite : ja fiz tudo isso)')
            main_obj.time_shift = 0
            main_obj.time_init = time()
        elif self.HP_it<=0: # HP BAIXO ~ Heal de MP
            while input('\n\t WASTED, voce morreu, para ressucitar deveria comer alguma coisa, deveria correr um pouco, deveria relaxar um pouco ...')!='ja fiz tudo isso':
                print('\n \t \t Coma algo ! (digite : ja fiz tudo isso)')
            self.HP_it = HP
        elif False: # MP BAIXO ~ Comida
            pass
        else:
            main_obj.time_shift = time() - main_obj.time_init
            if POMO_MIN_SEC - main_obj.time_shift>=0:
                print()
                print( status( self.HP_it ,HP,'HP '+'('+ str(HP) + ')', RD) )
                print( status(POMO_MIN_SEC - main_obj.time_shift, POMO_MIN_SEC,'SP '+POMO_MIN_SEC_desc, GR) )
                print( status( self.MP_it ,MP,'MP '+'('+ str(MP) + ')',CY) )
                
                
                
    def healing(self):
        change = 0.5*self.MP_it
        self.MP_it = change
        self.HP_it = min( self.HP_it + change, HP )
        
    def uniform_study(self,repetition_number=100,nivel=20):
        def guard_exit_command(string): 
            os.system('cls')
            return string=='@exit'
        
        # thr.Thread( target = self.app.mainloop, args=() ).start()
        
        self.HP_it = HP
        self.MP_it = 0.2*MP
        change_question = True
        i = 0
        while i < repetition_number:
            try:
                self.rpg_status_update(self.main_obj)
            except:
                pass
                
            print('\nPERGUNTA ['+YL+' SORTEIO UNIFORME '+WT+'] :\n'+LINE_str)
            
            if change_question: 
                N = self.random_info(nivel)
                change_question = False
            else:
                print(2*'\n')
                print(4*' ' + N )
                print(2*'\n')
                
            if N == None: break
            print( 'MODO [ ' + GR+'ESTUDO'+' ] : { ', YL+'Nro de Sorteios :', RD+str(repetition_number-i)  ,' }'  )
            print(WT+LINE_str)
            
            print(' ['+RD+' ? (Erro)'+WT+','+GR+' G (Acerto)'+WT+','+CY+' @heal'+WT+' ...\n... @exit, @pdf, @pdf=, @shortcuts, @site, @tips, @content ]\n' )
            
            if self.show_tips.value():
                print('Paradigmas :'+CY+' (1) '+WT+'Nao existe informacao dificil de memorizar, caso sinta dificuldade tente dividir a informacao dificil em componentes menores'+CY+' (2) '+WT+'Use caderno ou verbalize, nossa memoria e acessada e influenciada atraves de estimulos externos'+CY+' (3) '+WT+' Informacoes Dificeis nao sao impossiveis de se lembrar, entretanto tais informacoes podem ser estimuladas por informacoes parecidas mais simples ou informacoes associadas'+CY+' (4) '+WT+' Informacoes parecidas competem entre si na consciencia e podem levar ao fenomeno da confusao, em que nem uma nem outra informacao e lembrada, para ser capaz de discriminar tais informacoes e interessante tentar lembrar de ambas e escrever em um papel sempre uma for requerida '+CY+' (5) '+WT+' A memorizacao se da pela repeticao, tentativa e erro \n')
            
                print('Sugestao de Algoritmo: '+GR+' (1) '+WT+'Tente Lembrar da Informacao' +GR+' (2) '+WT+'Se lembrar facilmente tente lembrar de pelo menos uma informacao associada e digite G'+GR+' (3) '+WT+'Caso nao se lembre tente lembrar uma informacao mais facil ou associada'+GR+' (4) '+WT+'Caso tenha esperanca de lembrar da informacao atraves do estimulo das informacoes associadas, continue a lembrar pequenas informacoes ate lembrar da informacao final'+GR+' (5) '+WT+'Caso nao se lembre ou nao tenha esperanca de lembrar digite ?')
            
            INP = input('\n>>>>>')
            if guard_exit_command(INP): break
            os.system('CLS')
            if self.states['dict'][N]!=0:
                if INP == '?':
                    self.states['dict'][N] = self.states['dict'][N] - 1
                    self.HP_it = self.HP_it - 1
                    change_question = True
                    i = i + 1
                elif INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
                    self.MP_it = min( self.MP_it + 1, MP )
                    change_question = True
                    i = i + 1
                elif INP == '@heal':
                    self.healing()
                elif try_substr( INP, 0, len('@pdf=')  ) == '@pdf=':
                    X = try_substr( INP, len('@pdf='), 'all'  )
                    try:
                        if X in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict']:
                            Y = self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][X]
                            Z = self.main_obj.states['default pdf reader']+' '+Y
                            print(Z)
                            os.system( Z )
                    except:
                        try:
                            os.system( '"'+self.main_obj.states['default pdf reader']+'" '+X)
                        except:
                            print('Nao Foi Possivel Carregar o Arquivo')
                elif INP =='@pdf':
                    os.system('"'+self.main_obj.states['default pdf reader']+'"')
                elif INP =='@file explorer':
                    #proc = sbp.Popen('python python_menu07082020.py',creationflags = sbp.CREATE_NEW_CONSOLE )
                    #stdout_data, stderr_data = proc.communicate()
                    #print(stdout_data)
                    #proc.kill()
                    pass
                elif INP == '@site': 
                    X = find_url(N)
                    if X!='':
                        try:
                            os.system(self.main_obj.states['default browser']+' '+X)
                        except:
                            print(RD+'INVALID URL')
                            os.system('pause')
                    else:
                        print(RD+'NO URL FOUND')
                        os.system('pause')
                elif INP == '@tips':
                    self.show_tips.toggle()
                elif INP == '@content':
                    self.show_dict_content.toggle()
                elif INP == '@shortcuts':
                    print('Biblioteca : \n')
                    for iii in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'].keys():
                        print( GR,iii )
                        print( len(iii)*'-' )
                        print('\t' ,YL, self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][iii] )
                    print()
            else:
                if INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
                    self.MP_it = min( self.MP_it + 1, MP )
                    change_question = True
                    i = i + 1
                elif INP == '?':
                    #self.states['dict'][N] = self.states['dict'][N] - 1
                    self.HP_it = self.HP_it - 1
                    change_question = True
                    i = i + 1
                elif INP == '@heal':
                    self.healing()
                elif try_substr( INP, 0, len('@pdf=')  ) == '@pdf=':
                    X = try_substr( INP, len('@pdf='), 'all'  )
                    try:
                        if X in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict']:
                            Y = self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][X]
                            Z = self.main_obj.states['default pdf reader']+' '+Y
                            print(Z)
                            os.system( Z )
                    except:
                        try:
                            os.system( '"'+self.main_obj.states['default pdf reader']+'" '+X)
                        except:
                            print('Nao Foi Possivel Carregar o Arquivo')
                elif INP =='@pdf':
                    os.system('"'+self.main_obj.states['default pdf reader']+'"')
                elif INP =='@file explorer':
                    proc = sbp.Popen('python python_menu07082020.py',creationflags = sbp.CREATE_NEW_CONSOLE )
                    stdout_data, stderr_data = proc.communicate()
                    print(stdout_data)
                    proc.kill()
                elif INP == '@site': 
                    print(RD+'\n Se o @site nao abrir o navegador, reinicie o navegador ou feche e tente ... \n ... novamente \n')
                    X = find_url(N)
                    if X!='':
                        try:
                            os.system(self.main_obj.states['default browser']+' '+X)
                        except:
                            print(RD+'INVALID URL')
                            os.system('pause')
                    else:
                        print(RD+'NO URL FOUND')
                        os.system('pause')
                elif INP == '@tips':
                    self.show_tips.toggle()
                elif INP == '@content':
                    self.show_dict_content.toggle()
                elif INP == '@shortcuts':
                    print('Biblioteca : \n')
                    for iii in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'].keys():
                        print( GR,iii )
                        print( len(iii)*'-' )
                        print('\t' ,YL, self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][iii] ) 
                    print()    
            X = self.states['dict']
            
            if self.show_dict_content.value():
                print()
                self.print_dict_info()
        self.save()
    def __repr__(self):
        STRING = GR+"""
    @exit ou @origem : para retornar a interface principal
    @pdf e @pdf= : funcionam como na interface principal
    @create : Cria arquivo para inventario de informacoes
    @load : Abre file explorer para selecionar arquivo
    @reload : Recarrega o mesmo arquivo anterior
    @reset study : Coloca todas as informacoes em nivel zero
    @split : Para ser usado em inventarios muito grandes, divide
             o inventario em dois arquivos com metade dos itens
    @editor : Edita o inventario de informacoes
    @start : inicia um novo estudo com selecao aleatoria
        @start=NUMERO : Numero de Sorteios
        @start=(NUMERO_SORTEIOS,NUMERO_NIVEL) : 
            Configura numero de sorteios e o nivel do estudo nivel zero 
            sorteia apenas as novas informacoes nivel diferente de zero
            sorteia as informacoes com no maximo NUMERO_NIVEL de acertos
        """
        return STRING

class stats_rpgBrainwasher(rpgBrainwasher):
    def __init__(self, filename, dad_ref, main_obj, txt_dir):
        rpgBrainwasher.__init__(self, filename, dad_ref, main_obj,txt_dir)
        self.__X = (True,False)
        self.show_tips = toggle_object(0,self.__X)
        self.show_dict_content = toggle_object(1,self.__X)
        self.stat_NA_NS = (0,1)
    def dict2content(self,dictionary):
        def title():
            self.states['content'] = self.title + '{ ' + self.states['text filename'] + ' }\n'
        def inventory():
            X = self.states['content']
            for J in dictionary.keys():
                if dictionary[J]==0:
                    X = X +J+'\n' 
                else:
                    X = X + dictionary[J]*'*'+' '+J+'\n' 
            self.states['content'] = X
        def stats():
            X = ''
            X = X + '# stats [ Acerto por Item ] { Total } : ' + str( self.stat_estudo_por_item() ) + '\n'
            X = X + '# stats [ Acerto por Sorteio ] { Ultimo Estudo } :' + str( 1.*self.stat_NA_NS[0]/self.stat_NA_NS[1] ) + '\n'
            try:
                X = X + '# stats [ Taxa de Lembranca ] : ' + str( 1.*self.stat_NA_NS[0]/self.stat_NA_NS[1]/self.stat_estudo_por_item() )+ '\n'
            except:
                X = X + '# stats [ Taxa de Lembranca ] : 0' + '\n'
            self.states['content'] = self.states['content'] + X
            
        title()
        inventory()
        stats()
    def stat_estudo_por_item(self): # NAO FINALIZADO
        D = self.states['dict']
        K = D.keys()
        L = len(K)
        S = 0
        for i in K:
            S = S + D[i]
        return 1.*S/L
    def uniform_study(self,repetition_number=100,nivel=20):
        def guard_exit_command(string): 
            os.system('cls')
            return string=='@exit'
        
        # thr.Thread( target = self.app.mainloop, args=() ).start()
        
        self.HP_it = HP
        self.MP_it = 0.2*MP
        change_question = True
        i = 0
        stat_NA_counter = 0 ; stat_NS_counter = 0;
        while i < repetition_number:
            try:
                self.rpg_status_update(self.main_obj)
            except:
                pass
                
            print('\nPERGUNTA ['+YL+' SORTEIO UNIFORME '+WT+'] :\n'+LINE_str)
            
            if change_question: 
                N = self.random_info(nivel)
                change_question = False
                stat_NS_counter = stat_NS_counter + 1
            else:
                print(2*'\n')
                print(4*' ' + N )
                print(2*'\n')
                
            if N == None: break
            print( 'MODO [ ' + GR+'ESTUDO'+' ] : { ', YL+'Nro de Sorteios :', RD+str(repetition_number-i)  ,' }'  )
            print(WT+LINE_str)
            
            print(' ['+RD+' ? (Erro)'+WT+','+GR+' G (Acerto)'+WT+','+CY+' @heal'+WT+' ...\n... @exit, @pdf, @pdf=, @shortcuts, @site, @tips, @content ]\n' )
            
            if self.show_tips.value():
                print('Paradigmas :'+CY+' (1) '+WT+'Nao existe informacao dificil de memorizar, caso sinta dificuldade tente dividir a informacao dificil em componentes menores'+CY+' (2) '+WT+'Use caderno ou verbalize, nossa memoria e acessada e influenciada atraves de estimulos externos'+CY+' (3) '+WT+' Informacoes Dificeis nao sao impossiveis de se lembrar, entretanto tais informacoes podem ser estimuladas por informacoes parecidas mais simples ou informacoes associadas'+CY+' (4) '+WT+' Informacoes parecidas competem entre si na consciencia e podem levar ao fenomeno da confusao, em que nem uma nem outra informacao e lembrada, para ser capaz de discriminar tais informacoes e interessante tentar lembrar de ambas e escrever em um papel sempre uma for requerida '+CY+' (5) '+WT+' A memorizacao se da pela repeticao, tentativa e erro \n')
            
                print('Sugestao de Algoritmo: '+GR+' (1) '+WT+'Tente Lembrar da Informacao' +GR+' (2) '+WT+'Se lembrar facilmente tente lembrar de pelo menos uma informacao associada e digite G'+GR+' (3) '+WT+'Caso nao se lembre tente lembrar uma informacao mais facil ou associada'+GR+' (4) '+WT+'Caso tenha esperanca de lembrar da informacao atraves do estimulo das informacoes associadas, continue a lembrar pequenas informacoes ate lembrar da informacao final'+GR+' (5) '+WT+'Caso nao se lembre ou nao tenha esperanca de lembrar digite ?')
            
            INP = input('\n>>>>>')
            if guard_exit_command(INP): 
                self.stat_NA_NS = (stat_NA_counter,stat_NS_counter)
                break
            os.system('CLS')
            if self.states['dict'][N]!=0:
                if INP == '?':
                    self.states['dict'][N] = self.states['dict'][N] - 1
                    self.HP_it = self.HP_it - 1
                    change_question = True
                    i = i + 1
                elif INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
                    self.MP_it = min( self.MP_it + 1, MP )
                    change_question = True
                    i = i + 1
                    stat_NA_counter = stat_NA_counter + 1
                elif INP == '@heal':
                    self.healing()
                elif try_substr( INP, 0, len('@pdf=')  ) == '@pdf=':
                    X = try_substr( INP, len('@pdf='), 'all'  )
                    try:
                        if X in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict']:
                            Y = self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][X]
                            Z = self.main_obj.states['default pdf reader']+' '+Y
                            print(Z)
                            os.system( Z )
                    except:
                        try:
                            os.system( '"'+self.main_obj.states['default pdf reader']+'" '+X)
                        except:
                            print('Nao Foi Possivel Carregar o Arquivo')
                elif INP =='@pdf':
                    os.system('"'+self.main_obj.states['default pdf reader']+'"')
                elif INP =='@file explorer':
                    #proc = sbp.Popen('python python_menu07082020.py',creationflags = sbp.CREATE_NEW_CONSOLE )
                    #stdout_data, stderr_data = proc.communicate()
                    #print(stdout_data)
                    #proc.kill()
                    pass
                elif INP == '@site': 
                    X = find_url(N)
                    if X!='':
                        try:
                            os.system(self.main_obj.states['default browser']+' '+X)
                        except:
                            print(RD+'INVALID URL')
                            os.system('pause')
                    else:
                        print(RD+'NO URL FOUND')
                        os.system('pause')
                elif INP == '@tips':
                    self.show_tips.toggle()
                elif INP == '@content':
                    self.show_dict_content.toggle()
                elif INP == '@shortcuts':
                    print('Biblioteca : \n')
                    for iii in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'].keys():
                        print( GR+iii)
                        print( len(iii)*'-' )
                        print('\t' ,YL,self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][iii] )
                    print()
            else:
                if INP == 'G':
                    self.states['dict'][N] = self.states['dict'][N] + 1
                    self.MP_it = min( self.MP_it + 1, MP )
                    change_question = True
                    i = i + 1
                    stat_NA_counter = stat_NA_counter + 1
                elif INP == '?':
                    #self.states['dict'][N] = self.states['dict'][N] - 1
                    self.HP_it = self.HP_it - 1
                    change_question = True
                    i = i + 1
                elif INP == '@heal':
                    self.healing()
                elif try_substr( INP, 0, len('@pdf=')  ) == '@pdf=':
                    X = try_substr( INP, len('@pdf='), 'all'  )
                    try:
                        if X in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict']:
                            Y = self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][X]
                            Z = self.main_obj.states['default pdf reader']+' '+Y
                            print(Z)
                            os.system( Z )
                    except:
                        try:
                            os.system( '"'+self.main_obj.states['default pdf reader']+'" '+X)
                        except:
                            print('Nao Foi Possivel Carregar o Arquivo')
                elif INP =='@pdf':
                    os.system('"'+self.main_obj.states['default pdf reader']+'"')
                elif INP =='@file explorer':
                    proc = sbp.Popen('python python_menu07082020.py',creationflags = sbp.CREATE_NEW_CONSOLE )
                    stdout_data, stderr_data = proc.communicate()
                    print(stdout_data)
                    proc.kill()
                elif INP == '@site': 
                    print(RD+'\n Se o @site nao abrir o navegador, reinicie o navegador ou feche e tente ... \n ... novamente \n')
                    X = find_url(N)
                    if X!='':
                        try:
                            os.system(self.main_obj.states['default browser']+' '+X)
                        except:
                            print(RD+'INVALID URL')
                            os.system('pause')
                    else:
                        print(RD+'NO URL FOUND')
                        os.system('pause')
                elif INP == '@tips':
                    self.show_tips.toggle()
                elif INP == '@content':
                    self.show_dict_content.toggle()
                elif INP == '@shortcuts':
                    print('Biblioteca : \n')
                    for iii in self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'].keys():
                        print( GR,iii )
                        print( len(iii)*'-' )
                        print('\t' ,YL,self.main_obj.network['BOOKSHELF INTERFACE'].states['dict'][iii] )
                    print()    
            X = self.states['dict']
            
            if self.show_dict_content.value():
                print()
                self.print_dict_info()
        self.stat_NA_NS = (stat_NA_counter,stat_NS_counter)
        self.save()  

# -------------------------------------------------------------------------------------
# MAIN LOOP
# -------------------------------------------------------------------------------------

class MainInterface(VerticalOrientedInterface): # FINALIZADO NA VERSAO
    def __init__(self,filename='main06072020',dad_ref=None):
        VerticalOrientedInterface.__init__(self,filename,dad_ref,None)
        
        self.time_shift = None
        self.time_init = None

        self.states['default pdf reader'] = ''
        self.states['default ebooks folder'] = 'C:'
        self.states['default text editor'] = 'start notepad'
        self.states['default browser'] = ''
        
        VerticalOrientedInterface.load(self)
        
        self.network['Interface de Origem'] = self
        self.desc = 'INTERFACE PRINCIPAL'
        
        self.network['BRAINWASHER INTERFACE'] = stats_rpgBrainwasher('brainWasher_08072020',self, self, project_dr+'study_inventories')
        
        self.network['BOOKSHELF INTERFACE'] = bookshelfInterface('bookshelf_09072020',self,self, project_dr+'books')
        self.network['BOOKSHELF INTERFACE'].desc = 'BOOKSHELF'
        self.network['BOOKSHELF INTERFACE'].title = '# Inventario de Shortcuts de Enderecos e Nomes de Livros: { ' + str(date.today()) + ' }\n# ... SHORTCUT : "ENDERECO" '
        self.network['BOOKSHELF INTERFACE'].states['text filename'] = 'books_shortcuts09072020'
        self.network['BOOKSHELF INTERFACE'].comm_load_text_file('books_shortcuts09072020')
        
        self.states['auto interface info']=True
        
        os.system('CLS')
        
    def up_callback(self,head,X):
        try:
            head.head = self.network['TASK MANAGER']
        except:
            pass
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def down_callback(self,head,X):
        try:
            head.head = self.network['BOOKSHELF INTERFACE']
        except:
            pass
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def left_callback(self,head,X):
        head.head = self.network['Interface de Origem']
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def right_callback(self,head,X):
        try:
            head.head = self.network['BRAINWASHER INTERFACE']
        except:
            pass
        if w32.GetWindowText( w32.GetForegroundWindow() )=='C:\Python\Python38\python.exe': 
            kbd.press('enter')
    def print_dict(self):
        print()
        print('filename :',self.states['filename'])
        print('pdf reader :', self.states['default pdf reader'])
        print('txt editor :', self.states['default text editor'])
        print('browser :', self.states['default browser'] )
        print()
    def commands(self, input_str, main_obj):
        if input_str == '@help':
            self.help_c()
            print(GR+"""""")
        else:
            return VerticalOrientedInterface.commands(self,input_str,main_obj)
    def __repr__(self):
        STRING = GR+"""
    Digite :
    
    @brain : Para Ir para Interface Brainwasher
             Ferramenta de Memorizacao por Sorteio Aleatorio de Nomes
    @books : Para Ir para Interface de Atalhos de Livros
    
    @set pdf reader : Para Selecionar leitor de PDF
                      Ira abrir um file explorer
    @set text editor : Para Selecionar editor de .txt
                       Ira abrir um file explorer
    @set browser : Para Selecionar um navegador
                   Ira abrir um file explorer
    @pdf : Abre o Leitor PDF

    @pdf=SHORTCUT : Abre arquivo especificado pelo SHORTCUT
                    Para editar shortcuts va para @books
                
        """
        return STRING
        
class MainHeadInterface(HeadInterface): # FINALIZADO NA VERSAO
    """
    """
    def __init__(self,filename, oriented_interface,main_obj):
        HeadInterface.__init__(self,filename, oriented_interface,main_obj)
        self.head = oriented_interface
    # callbacks de keyboard input    
    def up_callback(self,X):
        self.head.up_callback(self,X)
    def down_callback(self,X):
        self.head.down_callback(self,X)
    def left_callback(self,X):
        self.head.left_callback(self,X)
    def right_callback(self,X):
        self.head.right_callback(self,X)
    
    def commands(self,input_str,main_obj):
        if input_str == '@origem':
            save_head = self.head
            self.head = self.head.network['Interface de Origem']
        elif try_substr(input_str,0,len('@goto') ) == '@goto':
            try:
                self.head = self.head.network[ try_substr(input_str,len('@goto')+1, 'all' ) ]
            except:
                self.head.comm_show_network()
            return False
        elif input_str == '@testeiro':
            try:
                pass # teste()
            except:
                print(RD+'ERRO' )
            return False
        elif input_str == '@books' and self.head.desc =='INTERFACE PRINCIPAL':
            self.head = self.head.network[ 'BOOKSHELF INTERFACE' ]
            return False
        elif input_str == '@brain' and self.head.desc =='INTERFACE PRINCIPAL':
            self.head = self.head.network[ 'BRAINWASHER INTERFACE' ]
            return False
            
        elif input_str =='@set pdf reader':
            #main_obj.states['default pdf reader'] = input(' Endereco Completo ou [start NOME_DO_PROG] : ')
            proc = sbp.Popen('python default_external_progs_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE)
            proc.wait()
            with open('data_transfer','r') as fhandle:
                X = fhandle.read()
                if not os.path.isdir( X ):
                    main_obj.states['default pdf reader'] = os.path.join( X )
            proc.kill()
            return False
        elif input_str =='@pdf':
            os.system('"'+main_obj.states['default pdf reader']+'"')
            return False
        elif try_substr( input_str, 0, len('@pdf=')  ) == '@pdf=':
            X = try_substr( input_str, len('@pdf='), 'all'  )
            try:
                if X in main_obj.network['BOOKSHELF INTERFACE'].states['dict']:
                    Y = main_obj.network['BOOKSHELF INTERFACE'].states['dict'][X]
                    Z = main_obj.states['default pdf reader']+' '+Y
                    print(Z)
                    os.system( Z )
            except:
                try:
                    os.system( '"'+main_obj.states['default pdf reader']+'" '+X)
                except:                    print('Nao Foi Possivel Carregar o Arquivo')
            return False
        #elif input_str =='@set ebooks folder':
        #    main_obj.states['default ebooks folder'] = input( ' Endereco Completo ou [start NOME_DO_PROG] : ' )
        #    return False
        elif input_str =='@set text editor':
            #main_obj.states['default text editor'] = input( ' Endereco Completo ou [start #NOME_DO_PROG] : '  )
            #return False
            
            proc = sbp.Popen('python default_external_progs_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE)
            proc.wait()
            with open('data_transfer','r') as fhandle:
                X = fhandle.read()
                if not os.path.isdir( X ):
                    main_obj.states['default text editor'] = os.path.join( X )
            proc.kill()
            return False
        elif input_str =='@set browser':
            #main_obj.states['default text editor'] = input( ' Endereco Completo ou [start #NOME_DO_PROG] : '  )
            #return False
            
            proc = sbp.Popen('python default_external_progs_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE)
            proc.wait()
            with open('data_transfer','r') as fhandle:
                X = fhandle.read()
                if not os.path.isdir( X ):
                    main_obj.states['default browser'] = os.path.join( X )
            proc.kill()
            return False    
            
        elif input_str == '@file explorer':
            if True: return False
            proc = sbp.Popen('python default_external_progs_submenu.py',creationflags = sbp.CREATE_NEW_CONSOLE )
            stdout_data, stderr_data = proc.communicate()
            print(stdout_data)
            proc.kill()
            return False
        elif try_substr(input_str,0, len('@rand=(') ) == '@rand=(':
            X = try_substr(input_str, len('@rand=('), 'all' )[:-1]
            Y = X.split(',')
            try:
                print( WT,'\n\n\nRandom Integer :',CY, randint( int(Y[0]), int( Y[1] ) ) )
            except:
                print(RD+'Isto e um gerador de inteiros')    
        else:
            return self.head.commands(input_str,main_obj)        
                
def main(): # FINALIZADO NA VERSAO

    # Main Objects
    pos_0 = MainInterface()
    head = MainHeadInterface(filename='head06072020',oriented_interface=pos_0,main_obj=pos_0)
    
    # Main Loop
    count = 0
    print( YL+COM_str0 )
    
    # Pomodoro 
    pos_0.time_init = time()
    pos_0.time_shift = 0
    
    #print(RD+'Para mudar a cor e o tamanho da tela aperte com o botao direito do mouse\n ... e va para propriedades, depois reinicie o programa. \n\nSugestao: Mude a Cor do Texto para Branco')   
    
    while True:
        print( WT+LINE_str+WT+PROG_NAME_str+'\n'+WT+LINE_str)
        
        
        print( head.head )
        
        
        print( WT+LINE_str )
        if head.head.desc=='INTERFACE PRINCIPAL':
            print( WT+ '[ '+ RD + str(count) + WT+' : ' + head.head.short_desc() + WT+' ]' )
        else:
            print( WT+'[ ' + RD+str(count) + WT + ' : ' + WT+ head.head.network['Interface de Origem'].desc + WT+' > ' + head.head.short_desc() + WT+' ]' )
        
        if head.head.states['auto interface info']:
           head.head.print_dict()
        
        os.system('doskey /listsize=0')
        inp = input(' >>> ')
        inp = inp.lstrip()
        inp = inp.rstrip()
        os.system('CLS')
        
        # ACOES DE ITERACAO
        if head.commands(inp,pos_0): # Condicao de Saida de Loop
            head.states.update({'count' : count })
            head.head.save()
            break
        if head.head.states['return?']: # Condicao de Retorno para Interface Principal
            head.head.states['return?']=False
            head.head = pos_0
        os.chdir(project_dr)
        
        # ATUALIZACAO DE ITERACAO
        count = count + 1 

thr.Thread(  target = main , args=() ).start()
                        
#main()
os.chdir(dir_origem)

