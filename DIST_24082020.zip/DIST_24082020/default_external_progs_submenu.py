# Programa [ Python Menu Explorer ] ( Python File Explorer )

# ~ PROGRAMAS ESTUPIDOS EM PYTHON [ FILE EXPLORER ESTUPIDO TOSCO ]

# SABER : Basico da Linguagem Python, Basico da Orientacao a Objeto em Python, Importar Modulos

# 1) Display no Terminal/Standart Output Colorido ~ colorama feito por terceiros

# 2) Controle atraves dos botoes de setas do Teclado ~ keyboard feito por terceiros 

# 3) Memoriza a ultima posicao de selecao de diretorios ja visitados ~ memory_object

# 4) Fecha o programa quando aperta o botao escape ~ living_object

# 5) UNICA FUNCIONALIDADE ESTUPIDA : copia para o clipboard (control C) o endereco da selecao ~ pyperclip

# GLOBAL IMPORTS
import keyboard as kbd # permite criar escutas/listeners de inputs de botoes do teclado
from time import sleep # 
import threading as thr # Paradigma Threading threads ~ processos
import os,sys, platform, shutil # operational system 
import win32gui as w32 # 
import colorama # 
import pyperclip as ppc
import psutil

# Titulo
WDTITLE = 'default_external_progs_submenu'
os.system('title '+WDTITLE)

# GLOBAL VARS [ os ]
isdir = os.path.isdir
get_ext = os.path.splitext
main_dir = os.getcwd()
brainWasher_dir = os.path.join( os.getcwd(), 'brainWashers09072020' )

# GLOBAL VARS [ colorama ]
colorama.init()
CY = colorama.Style.BRIGHT + colorama.Fore.CYAN
RD = colorama.Style.BRIGHT + colorama.Fore.RED
BL = colorama.Style.BRIGHT + colorama.Fore.BLUE
GR = colorama.Style.BRIGHT + colorama.Fore.GREEN
YL = colorama.Style.BRIGHT + colorama.Fore.YELLOW
WT = colorama.Style.BRIGHT + colorama.Fore.WHITE

# GLOBAL VARs [ text editor extensions ]
L_EXT_TEXT_EDITOR = set( [ '.txt','.bat','.py','.c','.cpp','.cmake' ] )
L_EXT_PDF = set( [ '.pdf','.djvu','.epub' ] )
L_EXT_MUSIC_VIDEO = set( [ '.mp3','.mp4' ] )

# GLOBAL FUNCTIONS [ colorama ]
def print_long_pointed_list(container = [0,1,2], description = 'item :', position = 0, list_size = 10):
    count = 0
    for i in container:
        if count > position+ list_size or count < position -list_size:
            if count == position + list_size + 1 or count == position - list_size - 1:
                print('...')
        elif count == position:
            print( CY, description, i)
        else:
            print( WT, description, i)
        count = count + 1
        
def is_dirXfile(x):
    if isdir(x):
        return CY + '[-]'
    else:
        return GR + ' * '
        
def is_python_in_focus():
    return w32.GetWindowText( w32.GetForegroundWindow() )==WDTITLE

def open_in_text_editor(filepath):
    try:
        os.system('start notepad++'+' "'+ filepath +'"' )
    except:
        os.system('start notepad'+' "'+ filepath +'"' )

def open_in_pdf_viewer(filepath):
    try:
        os.system('C:\\STDU\\STDUViewerApp.exe '+' "'+ filepath +'"' )
    except:
        pass

def get_partition_list():
    L = []
    for i in psutil.disk_partitions():
        L.append( os.path.join( i[0] ) )
    return list(L)

# GLOBAL CLASSES
class memory_object(object):
    def __init__(self):
        self.states = {}
        self.memory = {}
    def default_states(self):
        self.states = {}
    def memorization(self,key):
        self.memory.update( { key: self.states } )
    def remembering(self,key):
        try:
            self.states = self.memory[ key ]
        except:
            self.default_states()
            
class living_object(object):
    def __init__(self):
        self.life = True
    def esc_call(self,x): 
        if not is_python_in_focus(): return None
        self.life = False
    def in_control(self):
        kbd.on_press_key('esc', self.esc_call)
        
class arrow_keys_interface_object(object):
    def __init__(self): 
        pass
    def display(self):
        os.system('cls')
        print('key pressed')
    def in_control(self):
        kbd.on_press_key('up', self.up_call)
        kbd.on_press_key('down', self.down_call)
        kbd.on_press_key('left', self.left_call)
        kbd.on_press_key('right', self.right_call)
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.display()

# --------------------------------- START FROM HERE -----------------------------------

class file_explorer(living_object, memory_object, arrow_keys_interface_object):
    def __init__(self):
        living_object.__init__(self)
        memory_object.__init__(self)
        arrow_keys_interface_object.__init__(self)
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        self.memory = { self.states['current_dir'] : self.states }
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def print_long_pointed_list(self): 
        container = self.states['list_dir']
        position = self.states['pos']
        list_size = 15
        count = 0
        for i in container:
            if count > position+ list_size or count < position -list_size:
                if count == position + list_size + 1 or count == position - list_size - 1:
                    print('...')
            elif count == position:
                print( is_dirXfile(i), YL, '>', i , '<')
            else:
                print( is_dirXfile(i), ' ', WT, i, ' ')
            count = count + 1
    def display(self):  
        os.system('cls')
        os.system('whoami')
        total, used, free = shutil.disk_usage( os.getcwd() )
        print(WT + 'Diretorio :', self.states['current_dir']) 
        print(CY,'  Used Space :',used,'/',total,WT)
        print(CY,'  Free Space :',free,'/',total,WT)
        print(CY,'  Tamanho :', len( self.states['list_dir'] ), WT,'\n')
        self.print_long_pointed_list()
    def in_control(self):
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] > 0:
            self.states['pos'] = self.states['pos'] - 1
        self.display()
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] + 1 < len( self.states['list_dir'] ) :
            self.states['pos'] = self.states['pos'] + 1
        self.display()
        ppc.copy( self.states['current_dir'] + '\\' + self.states['list_dir'][ self.states['pos'] ] )
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        if brainWasher_dir==os.getcwd(): return None
        OLD_DIR = self.states['current_dir']
        self.memorization( OLD_DIR )
        os.chdir('..')
        self.update()
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        
        if not isdir( self.states['list_dir'][ self.states['pos'] ] ): return None
        OLD_DIR = self.states['current_dir']
        self.memorization( OLD_DIR )
        try:
            os.chdir( self.states['list_dir'][ self.states['pos'] ] )
            self.update()
        except:
            os.chdir(OLD_DIR)
            self.update()
            print(RD+'\n ACCESS DENIED\n')
            os.system('pause')
        self.display()    
    def update(self):
        self.remembering( os.getcwd() )
    def default_states(self):
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        

class file_explorer31072020(file_explorer):
    def __init__(self):
        file_explorer.__init__(self)
    def esc_call(self,x):
        if not is_python_in_focus(): return None
        self.manually_dir()
        self.display()    
    def in_control(self):
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
        kbd.on_press_key('enter', self.enter_call)
    def manually_dir(self):
        OLD_DIR = os.getcwd()
        try:
            os.chdir( input('Diretorio :') )
            self.update()
        except:
            os.chdir( OLD_DIR )
            self.update()
    def enter_call(self,x):
        def text_editor_handle(ext):
            global L_EXT_TEXT_EDITOR
            if ext in L_EXT_TEXT_EDITOR:
                open_in_text_editor( self.states['list_dir'][ self.states['pos'] ] )
        def pdf_handle(ext):
            global L_EXT_PDF
            if ext in L_EXT_PDF:
                open_in_pdf_viewer( self.states['list_dir'][ self.states['pos'] ] )
        if not is_python_in_focus(): return None
        X, X_ext = get_ext( self.states['list_dir'][ self.states['pos'] ] )
        text_editor_handle(X_ext)
        pdf_handle(X_ext)

class menu_widget(arrow_keys_interface_object):
    """ 
    07082020 : NOT_TESTED : NOT_DEFINED
    menu_widget : item de uma lista com alguma funcionalidade especial que quando aperta right ele toma controle 
    
    > menu_widget * (S x T) Description ?
    ----------------------------------------------------------------------
    1) method [ .__repr__ ] : para imprimir uma string representado o item do menu
    2) method [ .in_control ] : quando aperta o botao de seta para direita o menu_widget deve tomar controle, isso deve ser definido dentro do menu_reader. Este metodo deve definir funcionalidades para o widget ativo.
    
    1) attribute [ .description ] : conteudo a ser retornado por __repr__
    ----------------------------------------------------------------------
    ...
    """
    def __init__(self, parent = None ,description='widget'):
        self.description = description
        self.parent = None
    def __repr__(self):
        return self.description
    def display(self):
        self.parent.display()    
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.parent.states['in_charge'] = self.parent
        self.parent.update()
        self.parent.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()

class file_explorer07082020(file_explorer,menu_widget):
    def __init__(self, directory):
        living_object.__init__(self)
        memory_object.__init__(self)
        arrow_keys_interface_object.__init__(self)
        OLD_DIR = os.getcwd()
        os.chdir(directory)
        self.states = { 'current_dir' : os.getcwd(), 'pos': 0, 'list_dir': os.listdir() }
        self.memory = { self.states['current_dir'] : self.states }
        os.chdir(OLD_DIR)
        
    def enter_call(self,x):
        if not is_python_in_focus(): return None
        OLD_DIR = os.getcwd()
        os.chdir(main_dir)
        with open('data_transfer','w') as fhandle:
            fhandle.write( os.path.join( OLD_DIR ,self.states['list_dir'][self.states['pos']] ) )
        self.life = False
    def in_control(self):
        os.chdir(self.states['current_dir'])
        kbd.unhook_all()
        living_object.in_control(self)
        arrow_keys_interface_object.in_control(self)
        kbd.on_press_key('enter', self.enter_call)
    def manually_dir(self):
        OLD_DIR = os.getcwd()
        try:
            os.chdir( input('Diretorio :') )
            self.update()
        except:
            os.chdir( OLD_DIR )
            self.update()
    def esc_call(self,x): pass
    def display(self):  
        file_explorer.display(self)
        print(YL + '\nPress enter to load the file in BrainWasher Interface'+WT)
        print(YL + 'Use arrow keys to navigate'+WT)
        
class menu_widget(arrow_keys_interface_object):
    """ 
    07082020 : NOT_TESTED : NOT_DEFINED
    menu_widget : item de uma lista com alguma funcionalidade especial que quando aperta right ele toma controle 
    
    > menu_widget * (S x T) Description ?
    ----------------------------------------------------------------------
    1) method [ .__repr__ ] : para imprimir uma string representado o item do menu
    2) method [ .in_control ] : quando aperta o botao de seta para direita o menu_widget deve tomar controle, isso deve ser definido dentro do menu_reader. Este metodo deve definir funcionalidades para o widget ativo.
    
    1) attribute [ .description ] : conteudo a ser retornado por __repr__
    ----------------------------------------------------------------------
    ...
    """
    def __init__(self, parent = None ,description='widget'):
        self.description = description
        self.parent = None
    def __repr__(self):
        return self.description
    def display(self):
        self.parent.display()   
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.parent.states['in_charge'] = self.parent
        self.parent.update()
        self.parent.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        # do something
        self.parent.display()    
        
class menu_explorer(file_explorer31072020, menu_widget):
    def __init__(self, widget_iterable):
        file_explorer31072020.__init__(self)
        self.states = { 
            'current_dir' : os.getcwd(), 
            'pos': 0, 
            'list_dir': os.listdir(),
            'list_wdg': widget_iterable,
            'in_charge': self
            }
        self.parent = self
        self.description = RD+'Main Menu'
    def esc_call(self,x):
        if not is_python_in_focus(): return None
    def in_control(self):
        file_explorer31072020.in_control(self)
    def enter_call(self,x):
        if not is_python_in_focus(): return None
    def default_states(self):
        pass
    def update(self):
        kbd.unhook_all()
        self.states['in_charge'].in_control()
    def print_long_pointed_list(self): 
        container = self.states['list_wdg']
        position = self.states['pos']
        list_size = 15
        count = 0
        for i in container:
            if count > position+ list_size or count < position -list_size:
                if count == position + list_size + 1 or count == position - list_size - 1:
                    print('...')
            elif count == position:
                print( YL, '>', i , YL+'<')
            else:
                print( ' ', WT, i, ' ')
            count = count + 1
    def display(self):  
        os.system('cls')
        print(WT + 'Diretorio :', self.states['current_dir']) 
        print(CY,'  Tamanho :', len( self.states['list_wdg'] ), WT,'\n')
        print(self.states['in_charge'],'\n')
        self.update()
        self.print_long_pointed_list()
    def up_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] > 0:
            self.states['pos'] = self.states['pos'] - 1
        self.display()
    def down_call(self,x): 
        if not is_python_in_focus(): return None
        if self.states['pos'] + 1 < len( self.states['list_wdg'] ) :
            self.states['pos'] = self.states['pos'] + 1
        self.display()
    def left_call(self,x): 
        if not is_python_in_focus(): return None
        self.states['in_charge'] = self.parent
        self.update()
        self.display()
    def right_call(self,x): 
        if not is_python_in_focus(): return None
        self.states['in_charge'] = self.states['list_wdg'][ self.states['pos'] ]
        self.update()
        self.states['in_charge'].display()

def main_thread(obj):
    obj.in_control()
    # obj.manually_dir()
    obj.display()
    while obj.life:
        sleep(1)

def main():
    if platform.system()!='Windows': return None # GUARD [ Windows Systems ]
    try:
        X = input('Endereco da Pasta de Programas ou da Particao :')    
        E = file_explorer07082020(os.path.join(X))
        THR_obj = thr.Thread( target = main_thread, args=(E,) )
        THR_obj.start()
    except:
        OLD_DIR = os.getcwd()
        os.chdir(main_dir)
        with open('data_transfer','w') as fhandle:
            fhandle.write( '' )
        return False
main()


